//
// Cree par Angel PASQUIN le 13/05/2024
//
// Description: Déclaration des fonctions de gestion des écritures et des lectures des données de performances des entraînements des athlètes
//

#ifndef MANAGE_ATHLETES_DATA_H
#define MANAGE_ATHLETES_DATA_H

int enregistrerPerformancesEntrainementsAthletes();
int chargerPerformancesEntrainementsAthletes();

#endif //MANAGE_ATHLETES_DATA_H
