//
// Cree par Angel PASQUIN le 13/05/2024
//
// Description: Déclaration des fonctions de gestion de l'historique des performances des entraînements des athlètes
//

#ifndef HYSTORY_H
#define HYSTORY_H

void visualiserHistorique();

#endif //HYSTORY_H
