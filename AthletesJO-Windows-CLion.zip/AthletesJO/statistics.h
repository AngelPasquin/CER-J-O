//
// Cree par Angel PASQUIN le 13/05/2024
//
// Description: Déclaration des fonctions des statistiques des performances des entraînements des athlètes
//
#ifndef STATISTICS_H_
#define STATISTICS_H_

void performancesAthlete();
void performancesJO();
void progressionAthlete();
void visualiserStatistiques();

#endif